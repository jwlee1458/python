print("파이썬 웰컴")

print("파이썬", "웰컴", "python")

print("파이썬 \n", "웰컴 \n")

print('파이썬 "python" 웰컴')
print("파이썬 'python' 웰컴")

print("""
파이썬은 좋아요
       python Thank~~
       "파이썬"
       파이썬 화이팅!!
       """)